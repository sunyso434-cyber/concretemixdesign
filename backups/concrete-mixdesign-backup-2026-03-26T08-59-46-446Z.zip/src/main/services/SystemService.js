const SystemParam = require('../db/models/SystemParam')
const { sequelize } = require('../db/database')
const fs = require('fs')
const path = require('path')
const { app } = require('electron')

class SystemService {
  // 获取所有系统参数
  async getAllParams() {
    try {
      return await SystemParam.findAll()
    } catch (error) {
      console.error('获取系统参数失败:', error)
      throw error
    }
  }

  // 根据名称获取系统参数
  async getParamByName(name) {
    try {
      return await SystemParam.findOne({ where: { name } })
    } catch (error) {
      console.error('获取系统参数失败:', error)
      throw error
    }
  }

  // 设置系统参数
  async setParam(name, value, type = 'system', description = '') {
    try {
      const param = await SystemParam.findOne({ where: { name } })
      if (param) {
        return await param.update({ value, type, description })
      } else {
        return await SystemParam.create({ name, value, type, description })
      }
    } catch (error) {
      console.error('设置系统参数失败:', error)
      throw error
    }
  }

  // 删除系统参数
  async deleteParam(name) {
    try {
      const param = await SystemParam.findOne({ where: { name } })
      if (param) {
        return await param.destroy()
      }
      return null
    } catch (error) {
      console.error('删除系统参数失败:', error)
      throw error
    }
  }

  // 初始化默认系统参数
  async initDefaultParams() {
    try {
      const defaultParams = [
        {
          name: 'defaultLanguage',
          value: 'zh-CN',
          type: 'system',
          description: '默认语言'
        },
        {
          name: 'defaultUnit',
          value: 'metric',
          type: 'system',
          description: '默认单位制'
        },
        {
          name: 'defaultStrength',
          value: 'C30',
          type: 'mixdesign',
          description: '默认强度等级'
        },
        {
          name: 'defaultSlump',
          value: '100',
          type: 'mixdesign',
          description: '默认坍落度(mm)'
        },
        {
          name: 'defaultEnvironment',
          value: '1',
          type: 'mixdesign',
          description: '默认环境类别'
        },
        {
          name: 'defaultDensity',
          value: '2400',
          type: 'mixdesign',
          description: '默认容重(kg/m³)'
        },
        // JGJ 55标准 - 回归系数
        {
          name: 'regressionAlphaA',
          value: '0.53',
          type: 'jgj55',
          description: '回归系数α_a（碎石默认0.53）'
        },
        {
          name: 'regressionAlphaB',
          value: '0.20',
          type: 'jgj55',
          description: '回归系数α_b（碎石默认0.20）'
        },
        // JGJ 55标准 - 强度标准差σ（按强度等级）
        {
          name: 'strengthStdDev_C20',
          value: '4.0',
          type: 'jgj55',
          description: 'C20及以下强度标准差σ(MPa)'
        },
        {
          name: 'strengthStdDev_C25',
          value: '5.0',
          type: 'jgj55',
          description: 'C25-C45强度标准差σ(MPa)'
        },
        {
          name: 'strengthStdDev_C45',
          value: '5.0',
          type: 'jgj55',
          description: 'C25-C45强度标准差σ(MPa)'
        },
        {
          name: 'strengthStdDev_C50',
          value: '6.0',
          type: 'jgj55',
          description: 'C50及以上强度标准差σ(MPa)'
        },
        // JGJ 55标准 - 强度等级与减水剂掺量关系
        {
          name: 'superplasticizerDosage_C20',
          value: '1.6',
          type: 'jgj55',
          description: 'C20减水剂掺量(%)'
        },
        {
          name: 'superplasticizerDosage_C25',
          value: '1.7',
          type: 'jgj55',
          description: 'C25减水剂掺量(%)'
        },
        {
          name: 'superplasticizerDosage_C30',
          value: '1.8',
          type: 'jgj55',
          description: 'C30减水剂掺量(%)'
        },
        {
          name: 'superplasticizerDosage_C35',
          value: '1.9',
          type: 'jgj55',
          description: 'C35减水剂掺量(%)'
        },
        {
          name: 'superplasticizerDosage_C40',
          value: '2.0',
          type: 'jgj55',
          description: 'C40减水剂掺量(%)'
        },
        {
          name: 'superplasticizerDosage_C45',
          value: '2.1',
          type: 'jgj55',
          description: 'C45减水剂掺量(%)'
        },
        {
          name: 'superplasticizerDosage_C50',
          value: '2.2',
          type: 'jgj55',
          description: 'C50减水剂掺量(%)'
        },
        // JGJ 55标准 - 减水剂掺量与减水率关系
        {
          name: 'waterReducingRatePer01Dosage',
          value: '2.0',
          type: 'jgj55',
          description: '每增加0.1%减水剂掺量，减水率增加的百分比(%)'
        },
        {
          name: 'autoBackup',
          value: 'true',
          type: 'backup',
          description: '自动备份'
        },
        {
          name: 'backupInterval',
          value: '7',
          type: 'backup',
          description: '备份间隔(天)'
        }
      ]

      for (const param of defaultParams) {
        const existing = await SystemParam.findOne({ where: { name: param.name } })
        if (!existing) {
          await SystemParam.create(param)
        }
      }

      console.log('系统参数初始化完成')
    } catch (error) {
      console.error('初始化系统参数失败:', error)
      throw error
    }
  }

  // 备份数据库
  async backupDatabase() {
    try {
      const backupDir = path.join(app.getPath('userData'), 'backups')
      if (!fs.existsSync(backupDir)) {
        fs.mkdirSync(backupDir, { recursive: true })
      }

      const timestamp = new Date().toISOString().replace(/[:.]/g, '-')
      const backupPath = path.join(backupDir, `backup-${timestamp}.sqlite`)
      const dbPath = path.join(app.getPath('userData'), 'concrete-mixdesign.db')

      if (fs.existsSync(dbPath)) {
        fs.copyFileSync(dbPath, backupPath)
        return backupPath
      } else {
        throw new Error('数据库文件不存在')
      }
    } catch (error) {
      console.error('备份数据库失败:', error)
      throw error
    }
  }

  // 恢复数据库
  async restoreDatabase(backupPath) {
    try {
      const dbPath = path.join(app.getPath('userData'), 'concrete-mixdesign.db')

      if (fs.existsSync(backupPath)) {
        fs.copyFileSync(backupPath, dbPath)
        return true
      } else {
        throw new Error('备份文件不存在')
      }
    } catch (error) {
      console.error('恢复数据库失败:', error)
      throw error
    }
  }

  // 导入数据
  async importData(filePath) {
    try {
      // 简化实现，实际应根据文件格式进行解析
      console.log('导入数据:', filePath)
      // 这里可以实现具体的导入逻辑
      return true
    } catch (error) {
      console.error('导入数据失败:', error)
      throw error
    }
  }

  // 导出数据
  async exportData(filePath) {
    try {
      // 简化实现，实际应根据需要导出的数据进行处理
      console.log('导出数据:', filePath)
      // 这里可以实现具体的导出逻辑
      return true
    } catch (error) {
      console.error('导出数据失败:', error)
      throw error
    }
  }
}

module.exports = new SystemService()
