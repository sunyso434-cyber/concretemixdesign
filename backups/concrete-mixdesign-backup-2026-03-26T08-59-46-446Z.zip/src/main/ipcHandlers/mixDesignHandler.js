const { ipcMain } = require('electron')
const MixDesignService = require('../services/MixDesignService')

class MixDesignHandler {
  constructor() {
    this.registerHandlers()
  }

  registerHandlers() {
    // 获取所有配合比方案
    ipcMain.handle('getAllMixDesigns', async () => {
      try {
        const mixDesigns = await MixDesignService.getAllMixDesigns()
        return { success: true, data: mixDesigns }
      } catch (error) {
        return { success: false, error: error.message }
      }
    })

    // 根据ID获取配合比方案
    ipcMain.handle('getMixDesignById', async (_, id) => {
      try {
        const mixDesign = await MixDesignService.getMixDesignById(id)
        return { success: true, data: mixDesign }
      } catch (error) {
        return { success: false, error: error.message }
      }
    })

    // 创建配合比方案
    ipcMain.handle('createMixDesign', async (_, data) => {
      try {
        const mixDesign = await MixDesignService.createMixDesign(data)
        return { success: true, data: mixDesign }
      } catch (error) {
        return { success: false, error: error.message }
      }
    })

    // 更新配合比方案
    ipcMain.handle('updateMixDesign', async (_, { id, data }) => {
      try {
        const mixDesign = await MixDesignService.updateMixDesign(id, data)
        return { success: true, data: mixDesign }
      } catch (error) {
        return { success: false, error: error.message }
      }
    })

    // 删除配合比方案
    ipcMain.handle('deleteMixDesign', async (_, id) => {
      try {
        await MixDesignService.deleteMixDesign(id)
        return { success: true }
      } catch (error) {
        return { success: false, error: error.message }
      }
    })

    // 计算配合比
    ipcMain.handle('calculateMixDesign', async (_, params) => {
      try {
        const result = await MixDesignService.calculateMixDesign(params)
        return { success: true, data: result }
      } catch (error) {
        return { success: false, error: error.message }
      }
    })

    // 验证配合比
    ipcMain.handle('validateMixDesign', async (_, mixDesign) => {
      try {
        const result = await MixDesignService.validateMixDesign(mixDesign)
        return { success: true, data: result }
      } catch (error) {
        return { success: false, error: error.message }
      }
    })

    // 优化配合比
    ipcMain.handle('optimizeMixDesign', async (_, mixDesign) => {
      try {
        const result = await MixDesignService.optimizeMixDesign(mixDesign)
        return { success: true, data: result }
      } catch (error) {
        return { success: false, error: error.message }
      }
    })
  }
}

module.exports = new MixDesignHandler()
