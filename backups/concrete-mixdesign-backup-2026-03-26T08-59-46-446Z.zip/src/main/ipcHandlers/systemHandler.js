const systemService = require('../services/SystemService')

class SystemHandler {
  // 初始化系统处理器
  static init(win) {
    // 获取所有系统参数
    win.webContents.on('get-all-params', async (event) => {
      try {
        const params = await systemService.getAllParams()
        event.sender.send('get-all-params-reply', { success: true, data: params })
      } catch (error) {
        event.sender.send('get-all-params-reply', { success: false, error: error.message })
      }
    })

    // 根据名称获取系统参数
    win.webContents.on('get-param-by-name', async (event, name) => {
      try {
        const param = await systemService.getParamByName(name)
        event.sender.send('get-param-by-name-reply', { success: true, data: param })
      } catch (error) {
        event.sender.send('get-param-by-name-reply', { success: false, error: error.message })
      }
    })

    // 设置系统参数
    win.webContents.on('set-param', async (event, { name, value, type, description }) => {
      try {
        const param = await systemService.setParam(name, value, type, description)
        event.sender.send('set-param-reply', { success: true, data: param })
      } catch (error) {
        event.sender.send('set-param-reply', { success: false, error: error.message })
      }
    })

    // 删除系统参数
    win.webContents.on('delete-param', async (event, name) => {
      try {
        await systemService.deleteParam(name)
        event.sender.send('delete-param-reply', { success: true })
      } catch (error) {
        event.sender.send('delete-param-reply', { success: false, error: error.message })
      }
    })

    // 备份数据库
    win.webContents.on('backup-database', async (event) => {
      try {
        const backupPath = await systemService.backupDatabase()
        event.sender.send('backup-database-reply', { success: true, data: backupPath })
      } catch (error) {
        event.sender.send('backup-database-reply', { success: false, error: error.message })
      }
    })

    // 恢复数据库
    win.webContents.on('restore-database', async (event, backupPath) => {
      try {
        await systemService.restoreDatabase(backupPath)
        event.sender.send('restore-database-reply', { success: true })
      } catch (error) {
        event.sender.send('restore-database-reply', { success: false, error: error.message })
      }
    })

    // 导入数据
    win.webContents.on('import-data', async (event, filePath) => {
      try {
        await systemService.importData(filePath)
        event.sender.send('import-data-reply', { success: true })
      } catch (error) {
        event.sender.send('import-data-reply', { success: false, error: error.message })
      }
    })

    // 导出数据
    win.webContents.on('export-data', async (event, filePath) => {
      try {
        await systemService.exportData(filePath)
        event.sender.send('export-data-reply', { success: true })
      } catch (error) {
        event.sender.send('export-data-reply', { success: false, error: error.message })
      }
    })
  }
}

module.exports = SystemHandler