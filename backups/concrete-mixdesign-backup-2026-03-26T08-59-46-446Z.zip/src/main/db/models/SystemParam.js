const { DataTypes } = require('sequelize')
const { sequelize } = require('../database')

const SystemParam = sequelize.define('SystemParam', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  name: {
    type: DataTypes.STRING,
    allowNull: false,
    unique: true
  },
  value: {
    type: DataTypes.STRING,
    allowNull: false
  },
  type: {
    type: DataTypes.STRING
  },
  description: {
    type: DataTypes.TEXT
  },
  status: {
    type: DataTypes.STRING,
    defaultValue: '启用'
  }
}, {
  tableName: 'systemParams',
  timestamps: true
})

module.exports = SystemParam
