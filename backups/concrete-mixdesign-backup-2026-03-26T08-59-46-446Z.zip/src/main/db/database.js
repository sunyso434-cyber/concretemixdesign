const { Sequelize } = require('sequelize')
const path = require('path')
const { app } = require('electron')

// 数据库文件路径
const dbPath = path.join(app.getPath('userData'), 'concrete-mixdesign.db')

// 创建Sequelize实例，使用sqlite3
const sequelize = new Sequelize({
  dialect: 'sqlite',
  storage: dbPath,
  logging: false
})

// 导出sequelize实例
module.exports = { sequelize }