import React from 'react'
import { BrowserRouter as Router, Routes, Route, Navigate, Link } from 'react-router-dom'
import { ConfigProvider, Menu, Layout } from 'antd'
import zhCN from 'antd/lib/locale/zh_CN'
import 'antd/dist/reset.css'
import './index.css'

// 页面组件
import MaterialsPage from './pages/MaterialsPage'
import MixDesignPage from './pages/MixDesignPage'
import SchemesPage from './pages/SchemesPage'
import SettingsPage from './pages/SettingsPage'

const { Header, Content } = Layout

function App() {
  return (
    <ConfigProvider locale={zhCN}>
      <Router>
        <Layout style={{ minHeight: '100vh' }}>
          <Header style={{ 
            background: '#fff', 
            boxShadow: '0 2px 8px rgba(0, 0, 0, 0.09)',
            padding: '0 24px'
          }}>
            <div style={{ 
              display: 'flex', 
              alignItems: 'center', 
              height: '64px'
            }}>
              <div style={{ 
                fontSize: '18px', 
                fontWeight: '600', 
                color: '#1890ff',
                marginRight: '48px'
              }}>
                混凝土配合比设计系统
              </div>
              <Menu
                mode="horizontal"
                selectedKeys={[]}
                style={{ 
                  flex: 1, 
                  minWidth: 0, 
                  background: 'transparent',
                  borderBottom: 'none'
                }}
                items={[
                  {
                    key: 'materials',
                    label: <Link to="/materials">原材料管理</Link>
                  },
                  {
                    key: 'mixdesign',
                    label: <Link to="/mixdesign">配合比设计</Link>
                  },
                  {
                    key: 'schemes',
                    label: <Link to="/schemes">方案管理</Link>
                  },
                  {
                    key: 'settings',
                    label: <Link to="/settings">系统管理</Link>
                  }
                ]}
              />
            </div>
          </Header>
          <Content style={{ padding: '24px' }}>
            <div style={{ 
              maxWidth: '1200px', 
              margin: '0 auto',
              background: '#fff',
              padding: '24px',
              borderRadius: '8px',
              boxShadow: '0 2px 8px rgba(0, 0, 0, 0.09)'
            }}>
              <Routes>
                <Route path="/materials" element={<MaterialsPage />} />
                <Route path="/mixdesign" element={<MixDesignPage />} />
                <Route path="/schemes" element={<SchemesPage />} />
                <Route path="/settings" element={<SettingsPage />} />
                <Route path="/" element={<Navigate to="/materials" replace />} />
              </Routes>
            </div>
          </Content>
        </Layout>
      </Router>
    </ConfigProvider>
  )
}

export default App
