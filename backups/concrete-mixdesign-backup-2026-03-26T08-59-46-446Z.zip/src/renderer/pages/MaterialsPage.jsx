import React, { useState, useEffect } from 'react'
import { Card, Button, Table, Space, Modal, Form, Input, Select, message, Tag } from 'antd'

const { Option } = Select

const MaterialsPage = () => {
  const [materials, setMaterials] = useState([])
  const [loading, setLoading] = useState(false)
  const [modalVisible, setModalVisible] = useState(false)
  const [viewModalVisible, setViewModalVisible] = useState(false)
  const [currentMaterial, setCurrentMaterial] = useState(null)
  const [currentMaterialType, setCurrentMaterialType] = useState('水泥') // 当前选中的材料类型
  const [form] = Form.useForm()
  const [filterType, setFilterType] = useState('全部类型')

  // 材料类型选项
  const materialTypes = ['水泥', '粉煤灰', '矿渣粉', '细骨料', '粗骨料', '外加剂', '水']

  // 状态选项
  const statusOptions = ['正常', '停用', '待验证']

  // 细骨料标准筛孔尺寸（mm）
  const fineAggregateSieves = ['4.75', '2.36', '1.18', '0.60', '0.30', '0.15']

  // 粗骨料标准筛孔尺寸（mm）
  const coarseAggregateSieves = ['37.5', '31.5', '26.5', '19.0', '16.0', '9.50', '4.75']

  // 不同材料类型对应的性能参数配置
  const materialTypeFields = {
    '水泥': [
      { name: 'fineness', label: '细度 (m²/kg)', type: 'number', step: 1 }, // 细度参数
      { name: 'specificSurfaceArea', label: '比表面积 (m²/kg)', type: 'number', step: 1 }, // 比表面积参数
      { name: 'standardConsistency', label: '标准稠度用水量 (%)', type: 'number', step: 0.1 }, // 标准稠度用水量
      { name: 'initialSettingTime', label: '初凝时间 (min)', type: 'number', step: 1 }, // 初凝时间
      { name: 'finalSettingTime', label: '终凝时间 (min)', type: 'number', step: 1 }, // 终凝时间
      { name: 'flexuralStrength3d', label: '3天抗折强度 (MPa)', type: 'number', step: 0.1 }, // 3天抗折强度
      { name: 'flexuralStrength28d', label: '28天抗折强度 (MPa)', type: 'number', step: 0.1 }, // 28天抗折强度
      { name: 'compressiveStrength3d', label: '3天抗压强度 (MPa)', type: 'number', step: 0.1 }, // 3天抗压强度
      { name: 'compressiveStrength28d', label: '28天抗压强度 (MPa)', type: 'number', step: 0.1 } // 28天抗压强度
    ],
    '粉煤灰': [
      { name: 'fineness', label: '细度 (m²/kg)', type: 'number', step: 1 }, // 细度参数
      { name: 'waterDemandRatio', label: '需水量比 (%)', type: 'number', step: 0.1 }, // 需水量比
      { name: 'lossOnIgnition', label: '烧失量 (%)', type: 'number', step: 0.01 }, // 烧失量
      { name: 'activityIndex28d', label: '28天活性指数 (%)', type: 'number', step: 0.1 }, // 28天活性指数
      { name: 'influenceFactor_10', label: '影响系数 (10%)', type: 'number', step: 0.01 }, // 10%掺量影响系数
      { name: 'influenceFactor_20', label: '影响系数 (20%)', type: 'number', step: 0.01 }, // 20%掺量影响系数
      { name: 'influenceFactor_30', label: '影响系数 (30%)', type: 'number', step: 0.01 }, // 30%掺量影响系数
      { name: 'influenceFactor_40', label: '影响系数 (40%)', type: 'number', step: 0.01 }, // 40%掺量影响系数
      { name: 'influenceFactor_50', label: '影响系数 (50%)', type: 'number', step: 0.01 } // 50%掺量影响系数
    ],
    '矿渣粉': [
      { name: 'specificSurfaceArea', label: '比表面积 (m²/kg)', type: 'number', step: 1 }, // 比表面积参数
      { name: 'fluidityRatio', label: '流动度比 (%)', type: 'number', step: 0.1 }, // 流动度比
      { name: 'lossOnIgnition', label: '烧失量 (%)', type: 'number', step: 0.01 }, // 烧失量
      { name: 'activityIndex7d', label: '7天活性指数 (%)', type: 'number', step: 0.1 }, // 7天活性指数
      { name: 'activityIndex28d', label: '28天活性指数 (%)', type: 'number', step: 0.1 }, // 28天活性指数
      { name: 'influenceFactor_10', label: '影响系数 (10%)', type: 'number', step: 0.01 }, // 10%掺量影响系数
      { name: 'influenceFactor_20', label: '影响系数 (20%)', type: 'number', step: 0.01 }, // 20%掺量影响系数
      { name: 'influenceFactor_30', label: '影响系数 (30%)', type: 'number', step: 0.01 }, // 30%掺量影响系数
      { name: 'influenceFactor_40', label: '影响系数 (40%)', type: 'number', step: 0.01 }, // 40%掺量影响系数
      { name: 'influenceFactor_50', label: '影响系数 (50%)', type: 'number', step: 0.01 } // 50%掺量影响系数
    ],
    '细骨料': [
      { name: 'waterContent', label: '含水率 (%)', type: 'number', step: 0.1 }, // 含水率
      { name: 'mudContent', label: '含泥量 (%)', type: 'number', step: 0.01 }, // 含泥量
      { name: 'clayLumpContent', label: '泥块含量 (%)', type: 'number', step: 0.01 }, // 泥块含量
      ...fineAggregateSieves.map(sieve => ({ // 细骨料各筛孔累计筛余
        name: `sieve_${sieve.replace('.', '_')}`, 
        label: `${sieve}mm筛累计筛余 (%)`, 
        type: 'number', 
        step: 0.1 
      })),
      { name: 'mbValue', label: 'MB值', type: 'number', step: 0.01 }, // MB值
      { name: 'finenessModulus', label: '细度模数（根据筛分结果自动计算）', type: 'number', step: 0.01 } // 细度模数
    ],
    '粗骨料': [
      { name: 'waterContent', label: '含水率 (%)', type: 'number', step: 0.1 }, // 含水率
      { name: 'mudContent', label: '含泥量 (%)', type: 'number', step: 0.01 }, // 含泥量
      { name: 'clayLumpContent', label: '泥块含量 (%)', type: 'number', step: 0.01 }, // 泥块含量
      { name: 'needleFlakeContent', label: '针片状含量 (%)', type: 'number', step: 0.1 }, // 针片状含量
      { name: 'crushingValue', label: '压碎指标 (%)', type: 'number', step: 0.1 }, // 压碎指标
      ...coarseAggregateSieves.map(sieve => ({ // 粗骨料各筛孔累计筛余
        name: `sieve_${sieve.replace('.', '_')}`, 
        label: `${sieve}mm筛累计筛余 (%)`, 
        type: 'number', 
        step: 0.1 
      })),
      { name: 'grading', label: '级配（根据筛分结果自动匹配）', type: 'text' } // 级配
    ],
    '外加剂': [
      { name: 'solidContent', label: '含固量 (%)', type: 'number', step: 0.1 }, // 含固量
      { name: 'waterReducingRate', label: '减水率 (%)', type: 'number', step: 0.1 }, // 减水率
      { name: 'airContent', label: '含气量 (%)', type: 'number', step: 0.1 }, // 含气量
      { name: 'recommendedDosage', label: '推荐掺量 (%)', type: 'number', step: 0.01 }, // 推荐掺量
      { name: 'waterReducingRatePer01Dosage', label: '每0.1%掺量减水率增加 (%)', type: 'number', step: 0.1 } // 减水率与掺量关系
    ],
    '水': [
      { name: 'phValue', label: 'pH值', type: 'number', step: 0.1 }, // pH值
      { name: 'insolubleMatter', label: '不溶物含量 (mg/L)', type: 'number', step: 1 }, // 不溶物含量
      { name: 'solubleMatter', label: '可溶物含量 (mg/L)', type: 'number', step: 1 } // 可溶物含量
    ]
  }

  // 加载原材料列表
  const loadMaterials = async () => {
    setLoading(true)
    try {
      const result = await window.electron.ipcRenderer.invoke('getAllMaterials')
      if (result.success) {
        setMaterials(result.data)
      } else {
        message.error(result.error)
      }
    } catch (error) {
      message.error('加载原材料失败')
    } finally {
      setLoading(false)
    }
  }

  // 初始化加载
  useEffect(() => {
    loadMaterials()
  }, [])

  // 计算细骨料细度模数（根据GB/T 14684-2011）
  const calculateFinenessModulus = (values) => {
    // 获取各筛孔的累计筛余值，并确保转换为数字类型
    const sieve4_75 = Number(values?.sieve_4_75) || 0
    const sieve2_36 = Number(values?.sieve_2_36) || 0
    const sieve1_18 = Number(values?.sieve_1_18) || 0
    const sieve0_60 = Number(values?.sieve_0_60) || 0
    const sieve0_30 = Number(values?.sieve_0_30) || 0
    const sieve0_15 = Number(values?.sieve_0_15) || 0

    // 细度模数计算公式：Mx = [(A2.36 + A1.18 + A0.6 + A0.3 + A0.15) - 5×A4.75] / (100 - A4.75)
    // 根据GB/T 14684-2011标准，分母应该是(100 - A4.75)而不是100
    const denominator = 100 - sieve4_75
    // 防止分母为0的情况
    if (denominator <= 0) {
      return 0
    }
    const finenessModulus = (
      (sieve2_36 + sieve1_18 + sieve0_60 + sieve0_30 + sieve0_15) - 
      5 * sieve4_75
    ) / denominator

    // 保留两位小数
    return Number(finenessModulus.toFixed(2))
  }

  // 自动匹配粗骨料级配（根据GB/T 14685-2011）
  const matchCoarseAggregateGrading = (values) => {
    // 获取各筛孔的累计筛余值，并确保转换为数字类型
    const sieve37_5 = Number(values?.sieve_37_5) || 0
    const sieve31_5 = Number(values?.sieve_31_5) || 0
    const sieve26_5 = Number(values?.sieve_26_5) || 0
    const sieve19_0 = Number(values?.sieve_19_0) || 0
    const sieve16_0 = Number(values?.sieve_16_0) || 0
    const sieve9_50 = Number(values?.sieve_9_50) || 0
    const sieve4_75 = Number(values?.sieve_4_75) || 0

    // 级配匹配结果
    let gradingResult = '未匹配'

    // 检查常见连续级配范围（简化判断逻辑）
    // 5-10mm连续级配：主要通过9.5mm和4.75mm筛孔
    if (sieve9_50 >= 0 && sieve9_50 <= 15 && sieve4_75 >= 85 && sieve4_75 <= 100) {
      gradingResult = '5-10mm'
    }
    // 5-16mm连续级配：主要通过16mm、9.5mm和4.75mm筛孔
    else if (sieve16_0 >= 0 && sieve16_0 <= 10 && sieve9_50 >= 30 && sieve9_50 <= 60 && sieve4_75 >= 90 && sieve4_75 <= 100) {
      gradingResult = '5-16mm'
    }
    // 5-20mm连续级配：主要通过19mm、16mm、9.5mm和4.75mm筛孔
    else if (sieve19_0 >= 0 && sieve19_0 <= 15 && sieve16_0 >= 0 && sieve16_0 <= 20 && sieve9_50 >= 40 && sieve9_50 <= 80 && sieve4_75 >= 95 && sieve4_75 <= 100) {
      gradingResult = '5-20mm'
    }
    // 5-25mm连续级配：主要通过26.5mm、19mm、16mm、9.5mm和4.75mm筛孔
    else if (sieve26_5 >= 0 && sieve26_5 <= 10 && sieve19_0 >= 30 && sieve19_0 <= 70 && sieve16_0 >= 40 && sieve16_0 <= 80 && sieve9_50 >= 70 && sieve9_50 <= 95 && sieve4_75 >= 95 && sieve4_75 <= 100) {
      gradingResult = '5-25mm'
    }
    // 5-31.5mm连续级配：主要通过31.5mm、26.5mm、19mm、16mm、9.5mm和4.75mm筛孔
    else if (sieve31_5 >= 0 && sieve31_5 <= 15 && sieve26_5 >= 0 && sieve26_5 <= 20 && sieve19_0 >= 30 && sieve19_0 <= 70 && sieve16_0 >= 40 && sieve16_0 <= 80 && sieve9_50 >= 70 && sieve9_50 <= 95 && sieve4_75 >= 95 && sieve4_75 <= 100) {
      gradingResult = '5-31.5mm'
    }
    // 5-40mm连续级配：主要通过37.5mm、31.5mm、19mm、9.5mm和4.75mm筛孔
    else if (sieve37_5 >= 0 && sieve37_5 <= 15 && sieve31_5 >= 0 && sieve31_5 <= 20 && sieve19_0 >= 30 && sieve19_0 <= 70 && sieve9_50 >= 70 && sieve9_50 <= 95 && sieve4_75 >= 95 && sieve4_75 <= 100) {
      gradingResult = '5-40mm'
    }

    return gradingResult
  }

  // 处理表单值变化，自动计算细度模数或匹配级配
  const handleFormValuesChange = (changedValues, allValues) => {
    // 当材料类型是细骨料时计算细度模数
    if (currentMaterialType === '细骨料') {
      // 检查是否是筛孔相关的字段发生了变化
      const sieveFields = fineAggregateSieves.map(s => `sieve_${s.replace('.', '_')}`)
      const hasSieveChange = Object.keys(changedValues).some(key => sieveFields.includes(key))
      
      if (hasSieveChange) {
        // 计算细度模数
        const fm = calculateFinenessModulus(allValues)
        // 设置细度模数字段的值
        form.setFieldsValue({ finenessModulus: fm })
        console.log('自动计算细度模数:', fm) // 调试日志：细度模数计算结果
      }
    }
    // 当材料类型是粗骨料时自动匹配级配
    else if (currentMaterialType === '粗骨料') {
      // 检查是否是筛孔相关的字段发生了变化
      const sieveFields = coarseAggregateSieves.map(s => `sieve_${s.replace('.', '_')}`)
      const hasSieveChange = Object.keys(changedValues).some(key => sieveFields.includes(key))
      
      if (hasSieveChange) {
        // 匹配级配
        const grading = matchCoarseAggregateGrading(allValues)
        // 设置级配字段的值
        form.setFieldsValue({ grading: grading })
        console.log('自动匹配级配:', grading) // 调试日志：级配匹配结果
      }
    }
  }

  // 处理材料类型变化
  const handleMaterialTypeChange = (value) => {
    setCurrentMaterialType(value) // 更新当前材料类型状态
    console.log('材料类型已变更为:', value) // 调试日志：材料类型变化
  }

  // 打开添加/编辑模态框
  const openModal = (material = null) => {
    setCurrentMaterial(material)
    if (material) {
      setCurrentMaterialType(material.type || '水泥') // 设置当前材料类型
      form.setFieldsValue(material) // 如果是编辑，设置已有材料的值
    } else {
      setCurrentMaterialType('水泥') // 重置为默认材料类型
      // 如果是新增，设置默认值
      form.setFieldsValue({
        type: '水泥', // 默认材料类型
        status: '正常' // 默认状态
      })
    }
    setModalVisible(true)
  }

  // 关闭模态框
  const closeModal = () => {
    setModalVisible(false)
    setCurrentMaterial(null)
    form.resetFields()
  }

  // 保存材料
  const saveMaterial = async () => {
    try {
      console.log('开始保存材料，验证表单...') // 调试日志：开始保存
      const values = await form.validateFields()
      console.log('表单验证通过，值为:', values) // 调试日志：表单值
      let result
      if (currentMaterial) {
        console.log('更新现有材料，ID:', currentMaterial.id) // 调试日志：更新操作
        result = await window.electron.ipcRenderer.invoke('updateMaterial', {
          id: currentMaterial.id,
          data: values
        })
      } else {
        console.log('创建新材料') // 调试日志：创建操作
        result = await window.electron.ipcRenderer.invoke('createMaterial', values)
      }
      console.log('保存结果:', result) // 调试日志：保存结果
      if (result.success) {
        message.success(currentMaterial ? '更新成功' : '添加成功')
        closeModal()
        loadMaterials()
      } else {
        message.error(result.error)
      }
    } catch (error) {
      console.error('保存失败，错误信息:', error) // 调试日志：错误信息
      message.error('保存失败: ' + (error.message || '未知错误'))
    }
  }

  // 删除材料
  const deleteMaterial = async (id) => {
    try {
      const result = await window.electron.ipcRenderer.invoke('deleteMaterial', id)
      if (result.success) {
        message.success('删除成功')
        loadMaterials()
      } else {
        message.error(result.error)
      }
    } catch (error) {
      message.error('删除失败')
    }
  }

  // 查看材料详情
  const viewMaterial = (material) => {
    setCurrentMaterial(material)
    setCurrentMaterialType(material.type || '水泥')
    form.setFieldsValue(material)
    setViewModalVisible(true)
  }

  // 生成试验报告
  const generateTestReport = (material) => {
    message.info('生成试验报告功能开发中')
  }

  // 导入数据
  const importData = () => {
    message.info('导入数据功能开发中')
  }

  // 导出数据
  const exportData = () => {
    message.info('导出数据功能开发中')
  }

  // 渲染状态标签
  const renderStatusTag = (status) => {
    switch (status) {
      case '正常':
        return <Tag color="green">合格</Tag>
      case '待验证':
        return <Tag color="orange">待检</Tag>
      case '停用':
        return <Tag color="red">停用</Tag>
      default:
        return <Tag>{status}</Tag>
    }
  }

  // 渲染材料类型标签
  const renderTypeTag = (type) => {
    switch (type) {
      case '水泥':
        return <Tag color="blue">水泥</Tag>
      case '细骨料':
      case '粗骨料':
        return <Tag color="orange">骨料</Tag>
      case '外加剂':
        return <Tag color="purple">外加剂</Tag>
      case '粉煤灰':
      case '矿渣粉':
        return <Tag color="gray">掺合料</Tag>
      case '水':
        return <Tag color="cyan">水</Tag>
      default:
        return <Tag>{type}</Tag>
    }
  }

  // 过滤材料
  const filteredMaterials = materials.filter(material => {
    if (filterType === '全部类型') return true
    return material.type === filterType
  })

  const columns = [
    {
      title: '原材料名称',
      dataIndex: 'name',
      key: 'name'
    },
    {
      title: '类型',
      dataIndex: 'type',
      key: 'type',
      render: (text) => renderTypeTag(text)
    },
    {
      title: '规格型号',
      dataIndex: 'specification',
      key: 'specification'
    },
    {
      title: '生产厂家',
      dataIndex: 'manufacturer',
      key: 'manufacturer'
    },
    {
      title: '入库日期',
      dataIndex: 'createdAt',
      key: 'createdAt',
      render: (text) => {
        if (!text) return '-'
        const date = new Date(text)
        return date.toISOString().split('T')[0]
      }
    },
    {
      title: '状态',
      dataIndex: 'status',
      key: 'status',
      render: (text) => renderStatusTag(text)
    },
    {
      title: '操作',
      key: 'action',
      render: (_, record) => (
        <Space size="middle">
          <Button size="small" onClick={() => viewMaterial(record)}>查看</Button>
          <Button size="small" onClick={() => openModal(record)}>编辑</Button>
          <Button size="small" danger onClick={() => deleteMaterial(record.id)}>删除</Button>
          <Button size="small" onClick={() => generateTestReport(record)}>生成报告</Button>
        </Space>
      )
    }
  ]

  return (
    <div>
      <div style={{ marginBottom: 24 }}>
        <h2 className="page-title">原材料管理</h2>
        <p className="page-subtitle">管理混凝土配合比所需的各类原材料</p>
      </div>

      <div className="action-bar">
        <div>
          <Button type="primary" className="custom-btn" onClick={() => openModal()}>添加原材料</Button>
          <Button className="custom-btn" style={{ marginLeft: 8 }} onClick={importData}>导入数据</Button>
          <Button className="custom-btn" style={{ marginLeft: 8 }} onClick={exportData}>导出数据</Button>
        </div>
        <Select 
          style={{ width: 150 }} 
          value={filterType}
          onChange={setFilterType}
        >
          <Option value="全部类型">全部类型</Option>
          {materialTypes.map(type => (
            <Option key={type} value={type}>{type}</Option>
          ))}
        </Select>
      </div>

      <Card className="custom-card">
        <Table 
          className="custom-table"
          dataSource={filteredMaterials.map(m => ({ ...m, key: m.id }))} 
          columns={columns} 
          loading={loading}
          pagination={{ 
            pageSize: 10,
            showSizeChanger: true,
            showQuickJumper: true,
            showTotal: (total) => `共 ${total} 条记录`
          }}
        />
      </Card>

      <Modal
        className="custom-modal"
        title={currentMaterial ? '编辑材料' : '添加材料'}
        open={modalVisible}
        onOk={saveMaterial}
        onCancel={closeModal}
        width={800}
        destroyOnClose
      >
        <Form 
          className="custom-form"
          form={form} 
          layout="vertical"
          onValuesChange={handleFormValuesChange} // 监听表单值变化，自动计算细度模数
        >
          <Form.Item name="name" label="材料名称" rules={[{ required: true, message: '请输入材料名称' }]}>
            <Input placeholder="请输入材料名称" />
          </Form.Item>
          <Form.Item name="type" label="材料类型" rules={[{ required: true, message: '请选择材料类型' }]}>
            <Select 
              placeholder="请选择材料类型" 
              onChange={handleMaterialTypeChange} // 监听材料类型变化
            >
              {materialTypes.map(type => (
                <Option key={type} value={type}>{type}</Option>
              ))}
            </Select>
          </Form.Item>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
            <Form.Item name="specification" label="规格">
              <Input placeholder="请输入规格" />
            </Form.Item>
            <Form.Item name="manufacturer" label="生产厂家">
              <Input placeholder="请输入生产厂家" />
            </Form.Item>
            <Form.Item name="density" label="密度 (g/cm³)">
              <Input type="number" placeholder="请输入密度" step="0.01" />
            </Form.Item>
            <Form.Item name="price" label="单价 (元/吨)">
              <Input type="number" placeholder="请输入单价" step="0.01" />
            </Form.Item>
          </div>
          
          {/* 根据当前材料类型动态渲染性能参数 */}
          {materialTypeFields[currentMaterialType]?.map((field, index) => (
            <Form.Item 
              key={field.name} 
              name={field.name} 
              label={field.label}
            >
              {field.type === 'number' ? (
                <Input 
                  type="number" 
                  placeholder={`请输入${field.label}`} 
                  step={field.step}
                />
              ) : (
                <Input placeholder={`请输入${field.label}`} />
              )}
            </Form.Item>
          ))}
          
          <Form.Item name="status" label="状态" rules={[{ required: true, message: '请选择状态' }]}>
            <Select placeholder="请选择状态">
              {statusOptions.map(status => (
                <Option key={status} value={status}>{status}</Option>
              ))}
            </Select>
          </Form.Item>
          <Form.Item name="notes" label="备注">
            <Input.TextArea placeholder="请输入备注" rows={4} />
          </Form.Item>
        </Form>
      </Modal>

      {/* 查看材料详情模态框 */}
      <Modal
        className="custom-modal"
        title="材料详情"
        open={viewModalVisible}
        onCancel={() => setViewModalVisible(false)}
        footer={[
          <Button key="close" className="custom-btn" onClick={() => setViewModalVisible(false)}>关闭</Button>
        ]}
        width={800}
      >
        <Form 
          className="custom-form"
          form={form} 
          layout="vertical"
        >
          <Form.Item name="name" label="材料名称">
            <Input placeholder="请输入材料名称" disabled />
          </Form.Item>
          <Form.Item name="type" label="材料类型">
            <Select 
              placeholder="请选择材料类型" 
              disabled
            >
              {materialTypes.map(type => (
                <Option key={type} value={type}>{type}</Option>
              ))}
            </Select>
          </Form.Item>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
            <Form.Item name="specification" label="规格">
              <Input placeholder="请输入规格" disabled />
            </Form.Item>
            <Form.Item name="manufacturer" label="生产厂家">
              <Input placeholder="请输入生产厂家" disabled />
            </Form.Item>
            <Form.Item name="density" label="密度 (g/cm³)">
              <Input type="number" placeholder="请输入密度" step="0.01" disabled />
            </Form.Item>
            <Form.Item name="price" label="单价 (元/吨)">
              <Input type="number" placeholder="请输入单价" step="0.01" disabled />
            </Form.Item>
          </div>
          
          {/* 根据当前材料类型动态渲染性能参数 */}
          {materialTypeFields[currentMaterialType]?.map((field, index) => (
            <Form.Item 
              key={field.name} 
              name={field.name} 
              label={field.label}
            >
              {field.type === 'number' ? (
                <Input 
                  type="number" 
                  placeholder={`请输入${field.label}`} 
                  step={field.step}
                  disabled
                />
              ) : (
                <Input placeholder={`请输入${field.label}`} disabled />
              )}
            </Form.Item>
          ))}
          
          <Form.Item name="status" label="状态">
            <Select placeholder="请选择状态" disabled>
              {statusOptions.map(status => (
                <Option key={status} value={status}>{status}</Option>
              ))}
            </Select>
          </Form.Item>
          <Form.Item name="notes" label="备注">
            <Input.TextArea placeholder="请输入备注" rows={4} disabled />
          </Form.Item>
        </Form>
      </Modal>
    </div>
  )
}

export default MaterialsPage
