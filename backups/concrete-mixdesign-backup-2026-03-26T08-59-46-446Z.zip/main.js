const { app, BrowserWindow, ipcMain } = require('electron')
const path = require('path')
const { sequelize } = require('./src/main/db/database')
// 导入IPC处理器
require('./src/main/ipcHandlers/materialHandler')
require('./src/main/ipcHandlers/mixDesignHandler')
const SystemHandler = require('./src/main/ipcHandlers/systemHandler')

// 数据库连接
sequelize.authenticate()
  .then(() => {
    console.log('数据库连接成功')
    // 初始化数据库表
    const Material = require('./src/main/db/models/Material')
    const MixDesign = require('./src/main/db/models/MixDesign')
    const SystemParam = require('./src/main/db/models/SystemParam')
    sequelize.sync({ alter: true })
      .then(() => {
        console.log('数据库表同步完成')
        // 初始化预设材料
        const MaterialService = require('./src/main/services/MaterialService')
        MaterialService.initDefaultMaterials()
        // 初始化系统参数
        const SystemService = require('./src/main/services/SystemService')
        SystemService.initDefaultParams()
      })
      .catch(err => {
        console.error('数据库表同步失败:', err)
      })
  })
  .catch(err => {
    console.error('数据库连接失败:', err)
  })

// 创建窗口
function createWindow() {
  const mainWindow = new BrowserWindow({
    width: 1400,
    height: 900,
    webPreferences: {
      preload: path.join(__dirname, 'src/main/preload.js'),
      nodeIntegration: false,
      contextIsolation: true
    }
  })

  // 加载应用
  console.log('当前环境:', process.env.NODE_ENV)
  console.log('当前目录:', __dirname)
  console.log('应用路径:', app.getAppPath())
  
  // 始终加载Vite服务器，无论开发还是生产模式
  const viteUrl = 'http://localhost:3000'
  console.log('加载Vite服务器:', viteUrl)
  mainWindow.loadURL(viteUrl)
  
  // 监听加载失败事件
  mainWindow.webContents.on('did-fail-load', (event, errorCode, errorDescription, validatedURL, isMainFrame) => {
    console.error('页面加载失败:', errorCode, errorDescription, validatedURL)
  })
  
  // 监听控制台消息
  mainWindow.webContents.on('console-message', (event, level, message, line, sourceId) => {
    console.log('渲染进程控制台:', message)
  })
  
  // 监听渲染进程崩溃事件
  mainWindow.webContents.on('render-process-crashed', (event, killed) => {
    console.error('渲染进程崩溃:', killed)
  })
  
  // 监听加载完成事件
  mainWindow.webContents.on('did-finish-load', () => {
    console.log('页面加载完成')
    // 尝试执行一些JavaScript来检查页面状态
    mainWindow.webContents.executeJavaScript(`
      console.log('页面DOM加载完成');
      console.log('根元素:', document.getElementById('root'));
      console.log('React是否存在:', typeof React !== 'undefined');
      console.log('ReactDOM是否存在:', typeof ReactDOM !== 'undefined');
    `)
  })
  // 强制打开DevTools
  mainWindow.webContents.openDevTools({ mode: 'detach' })
  console.log('DevTools已打开')

  // 初始化系统处理器
  SystemHandler.init(mainWindow)
}

// 应用准备就绪
app.whenReady().then(() => {
  createWindow()

  app.on('activate', function () {
    if (BrowserWindow.getAllWindows().length === 0) createWindow()
  })
})

// 关闭所有窗口
app.on('window-all-closed', function () {
  if (process.platform !== 'darwin') app.quit()
})

// IPC事件处理
ipcMain.on('message', (event, arg) => {
  console.log(arg)
  event.reply('reply', 'pong')
})
