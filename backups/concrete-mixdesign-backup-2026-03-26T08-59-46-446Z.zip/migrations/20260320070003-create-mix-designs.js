'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up (queryInterface, Sequelize) {
    await queryInterface.createTable('mixDesigns', {
      id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true
      },
      name: {
        type: Sequelize.STRING,
        allowNull: false
      },
      projectName: {
        type: Sequelize.STRING
      },
      description: {
        type: Sequelize.TEXT
      },
      strengthGrade: {
        type: Sequelize.STRING,
        allowNull: false
      },
      slump: {
        type: Sequelize.FLOAT
      },
      environmentClass: {
        type: Sequelize.STRING
      },
      durabilityRequirement: {
        type: Sequelize.JSON
      },
      waterCementRatio: {
        type: Sequelize.FLOAT
      },
      sandRatio: {
        type: Sequelize.FLOAT
      },
      unitWeight: {
        type: Sequelize.FLOAT
      },
      materialsUsage: {
        type: Sequelize.JSON
      },
      validationResult: {
        type: Sequelize.JSON
      },
      status: {
        type: Sequelize.STRING,
        defaultValue: '正常'
      },
      remark: {
        type: Sequelize.TEXT
      },
      createdAt: {
        type: Sequelize.DATE,
        defaultValue: Sequelize.NOW
      },
      updatedAt: {
        type: Sequelize.DATE,
        defaultValue: Sequelize.NOW
      }
    });
  },

  async down (queryInterface, Sequelize) {
    await queryInterface.dropTable('mixDesigns');
  }
};
